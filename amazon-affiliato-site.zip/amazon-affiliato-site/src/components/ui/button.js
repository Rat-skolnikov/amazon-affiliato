import React from "react";

export function Button({ children }) {
  return (
    <button style={{
      backgroundColor: "#1f2937",
      color: "white",
      border: "none",
      padding: "10px 20px",
      borderRadius: 8,
      cursor: "pointer"
    }}>
      {children}
    </button>
  );
}
