import React from "react";

export function Card({ children }) {
  return <div style={{ background: "#fff", borderRadius: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>{children}</div>;
}

export function CardContent({ children }) {
  return <div style={{ padding: 16 }}>{children}</div>;
}
